a tutorial can be found at:
http://www.princeton.edu/~bmwtwo/skydrive-shortcut-tutorial/